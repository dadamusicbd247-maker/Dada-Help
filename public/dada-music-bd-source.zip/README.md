# DADA MUSIC BD - 320 kbps MP3 Audio Downloader

A full-stack application built with React, Vite, TypeScript, Tailwind CSS, and Express.

---

## 🚀 How to Run in VS Code (ধাপে ধাপে চালানোর নিয়ম):

### ১. ফোল্ডার ওপেন করুন
- জিপ ফাইলটি আনজিপ (Extract) করুন।
- VS Code ওপেন করে `File` > `Open Folder...` থেকে আনজিপ করা ফোল্ডারটি সিলেক্ট করুন।

### ২. ডিপেনডেন্সি ইন্সটল করুন (Dependencies Install)
- VS Code-এর টার্মিনাল ওপেন করুন (`Ctrl + ~` অথবা মেনু থেকে `Terminal` > `New Terminal`)।
- নিচের কমান্ডটি লিখে এন্টার চাপুন:
```bash
npm install
```

### ৩. অ্যাপটি রান করুন (Run App)
- টার্মিনালে নিচের কমান্ডটি লিখুন:
```bash
npm run dev
```

### ৪. ব্রাউজারে দেখুন
- ব্রাউজারে গিয়ে নিচের লিংকে প্রবেশ করুন:
```
http://localhost:3000
```

---

## 🛠️ Production Build (প্রোডাকশন বিল্ড করার জন্য):
```bash
npm run build
npm start
```

## 📁 প্রজেক্ট স্ট্রাকচার:
- `/src/App.tsx` - মূল ফ্রন্টএন্ড লেআউট ও স্টেট
- `/src/components/` - Navbar, Logo, LinkInputForm, AudioResultCard
- `/src/utils/` - অডিও প্রসেসিং ও ডাউনলোডার ইঞ্জিন
- `/server.ts` - ব্যাকএন্ড এক্সপ্রেস প্রক্সি ও অডিও স্ট্রিমিং সার্ভার
- `/vite.config.ts` - Vite কনফিগারেশন
