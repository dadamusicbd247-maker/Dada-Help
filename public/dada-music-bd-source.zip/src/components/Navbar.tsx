import React from 'react';
import { DadaMusicLogo } from './DadaMusicLogo';

export const Navbar: React.FC = () => {
  return (
    <header
      id="main-header"
      className="shrink-0 z-40 w-full border-b border-slate-200/90 bg-white/95 backdrop-blur-md shadow-2xs select-none"
    >
      <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 h-16 sm:h-18 lg:h-20 flex items-center justify-between">
        {/* Brand Left */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 lg:gap-4 min-w-0">
          {/* Universal Responsive Logo (40px mobile, 48px tablet, 56px PC) */}
          <DadaMusicLogo className="w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 drop-shadow-xs shrink-0" />

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2.5">
              <h1 className="text-sm sm:text-xl lg:text-2xl font-black tracking-tight text-slate-900 leading-none truncate">
                DADA MUSIC <span className="text-emerald-600">BD</span>
              </h1>
              <span className="text-[9px] sm:text-[11px] lg:text-xs uppercase font-extrabold tracking-wider px-1.5 sm:px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300/80 leading-none shrink-0">
                Official
              </span>
            </div>
            <p className="text-[10px] sm:text-xs lg:text-[13px] text-slate-500 font-medium mt-0.5 sm:mt-1 truncate">
              <span className="sm:hidden">High Quality 320 kbps MP3 Downloader</span>
              <span className="hidden sm:inline">Authentic 320 kbps Studio MP3 Downloader & Audio Converter</span>
            </p>
          </div>
        </div>

        {/* Engine Status Pill */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <div className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] sm:text-xs font-bold shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="sm:hidden">Active</span>
            <span className="hidden sm:inline">Engine Online</span>
          </div>
        </div>
      </div>
    </header>
  );
};

