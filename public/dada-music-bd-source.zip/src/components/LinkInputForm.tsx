import React, { useRef } from 'react';
import { Link2, Download, Loader2, X, AlertCircle, Code } from 'lucide-react';

interface LinkInputFormProps {
  url: string;
  setUrl: (url: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
  error: string | null;
}

export const LinkInputForm: React.FC<LinkInputFormProps> = ({
  url,
  setUrl,
  onAnalyze,
  isLoading,
  error,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    onAnalyze();
  };

  const isEmbedCode = url.includes('<iframe') || url.includes('<a ') || url.includes('src=');

  return (
    <div className="space-y-3">
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex flex-col sm:flex-row items-stretch gap-2 bg-white border border-slate-300 hover:border-slate-400 focus-within:!border-emerald-600 focus-within:ring-4 focus-within:ring-emerald-600/10 rounded-2xl p-2 sm:p-2.5 shadow-sm transition">
          <div className="relative flex-1 flex items-center min-w-0">
            <div className="pl-3.5 pr-2.5 text-slate-400 pointer-events-none shrink-0">
              {isEmbedCode ? (
                <Code className="w-5 h-5 text-emerald-600" />
              ) : (
                <Link2 className="w-5 h-5 text-emerald-600" />
              )}
            </div>
            <input
              ref={inputRef}
              id="share-link-input"
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste audio link, Suno URL, or embed code..."
              disabled={isLoading}
              className="w-full py-3 sm:py-2.5 bg-transparent text-slate-900 placeholder-slate-400 text-base focus:outline-none"
            />
            {url && (
              <button
                type="button"
                onClick={() => {
                  setUrl('');
                  inputRef.current?.focus();
                }}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg mr-1 transition cursor-pointer shrink-0"
                title="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            id="extract-audio-submit-btn"
            type="submit"
            disabled={isLoading || !url.trim()}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 sm:py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] disabled:opacity-40 disabled:hover:bg-emerald-600 disabled:cursor-not-allowed text-white font-bold text-base sm:text-sm shadow-xs transition cursor-pointer shrink-0"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing Audio...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>Get Audio</span>
              </>
            )}
          </button>
        </div>

        {/* Status indicator */}
        {isEmbedCode && (
          <div className="mt-2 px-1 text-xs">
            <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 font-medium">
              <Code className="w-3 h-3" />
              HTML Iframe / Embed Code Detected
            </span>
          </div>
        )}
      </form>

      {/* Error alert */}
      {error && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-900">Unable to download audio</p>
            <p className="text-xs text-rose-700 mt-0.5 leading-relaxed">{error}</p>
          </div>
        </div>
      )}
    </div>
  );
};
