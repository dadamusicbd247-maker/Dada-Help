/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LinkInputForm } from './components/LinkInputForm';
import { AudioResultCard } from './components/AudioResultCard';
import { ExtractedAudio } from './types';
import { ShieldCheck } from 'lucide-react';

export default function App() {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [extractedAudio, setExtractedAudio] = useState<ExtractedAudio | null>(null);

  // Clear any existing watermark/background from storage immediately
  useEffect(() => {
    try {
      localStorage.removeItem('dada_custom_bg');
      localStorage.removeItem('dada_watermark_img');
    } catch {}
  }, []);

  const handleAnalyzeAndDownload = async () => {
    if (!url.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url.trim() }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(
          data.error ||
            'Failed to extract audio from this link. Please ensure the link is public and accessible.'
        );
      }

      // Display the audio info card so user can click download when ready
      setExtractedAudio(data);
    } catch (err: any) {
      setError(
        err?.message || 'Failed to extract audio. Please check the URL and try again.'
      );
      setExtractedAudio(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setUrl('');
    setExtractedAudio(null);
    setError(null);
  };

  return (
    <div className="h-screen h-[100dvh] max-h-[100dvh] bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900 flex flex-col overflow-hidden font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Locked Header - Clean & Untouched */}
      <Navbar />

      {/* Middle Scrollable Content Container */}
      <main
        id="main-scrollable-content"
        className="flex-1 overflow-y-auto w-full overscroll-contain relative"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        {/* Main Interface Content */}
        <div className="relative z-10 max-w-2xl sm:max-w-3xl lg:max-w-3xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4 sm:pt-8 lg:pt-10 pb-8 sm:pb-12 flex flex-col">
          {/* Header and Title */}
          <div className="text-center mb-4 sm:mb-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 sm:py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] sm:text-xs font-semibold mb-2 sm:mb-3 shadow-2xs">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>100% Authentic MP3 &bull; 320 kbps High Quality</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] font-black tracking-tight text-slate-900 leading-tight">
              Paste Link & Download MP3
            </h2>

            <p className="mt-1 sm:mt-2 text-xs sm:text-sm md:text-base text-slate-600 max-w-xl mx-auto leading-relaxed">
              Paste any Suno AI link, embed code, Dropbox, or audio link to get authentic 320 kbps studio audio.
            </p>
          </div>

          {/* Core Input Form */}
          <div className="mb-3 sm:mb-4">
            <LinkInputForm
              url={url}
              setUrl={setUrl}
              onAnalyze={handleAnalyzeAndDownload}
              isLoading={isLoading}
              error={error}
            />
          </div>

          {/* Audio Result Card */}
          {extractedAudio && (
            <div className="mt-2 animate-in fade-in slide-in-from-bottom-3 duration-300">
              <AudioResultCard
                audio={extractedAudio}
                onReset={handleReset}
              />
            </div>
          )}

          {/* Reserved clean container slot for future tools */}
          <div id="future-tools-container" className="w-full mt-2" />
        </div>
      </main>

      {/* Bottom Locked Footer - Clean & Untouched */}
      <footer
        id="main-footer"
        className="shrink-0 z-40 w-full border-t border-slate-200/80 bg-white/95 backdrop-blur-md py-3 sm:py-3.5 px-4 sm:px-8 shadow-2xs select-none"
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-2">
          <p className="font-medium text-slate-600 text-center sm:text-left text-xs">
            DADA MUSIC BD &bull; 100% Authentic 320 kbps MP3 Audio Downloader
          </p>
          <p className="hidden sm:flex items-center gap-1.5 text-slate-400 text-xs font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Studio Audio Direct Stream
          </p>
        </div>
      </footer>
    </div>
  );
}
